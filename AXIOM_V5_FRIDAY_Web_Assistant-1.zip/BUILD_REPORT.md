# FRIDAY Android build and verification report — v1.2.0

## Implemented in this source update
- User-started microphone foreground service for background wake phrase listening.
- Persistent foreground-service notification and CPU partial wake lock while enabled.
- “Hey Friday” / “Friday” phrase detection and app foreground handoff.
- Android 14+ microphone foreground-service declarations and permissions.
- Optional AccessibilityService for user-requested Back, Home, notifications, quick settings, scrolling, and visible-text tapping (with confirmation in the UI).
- Settings controls for enabling the Accessibility permission and checking connection state.

## Static checks performed
- AndroidManifest.xml, accessibility service XML, and strings.xml parse successfully.
- JavaScript syntax check passes with Node.js.
- Source ZIP archive integrity is checked after packaging.

## Not verified in this environment
- Android Gradle compilation / Debug APK generation: Android SDK is not installed in this environment.
- Runtime behavior on physical Android devices: not tested.
- Wake phrase recognition quality, background survival, battery use, and offline recognition: device/provider-dependent and not tested.
- Accessibility automation on third-party apps: requires user opt-in and device testing; protected/custom UI may not expose accessible controls.

## Platform limitations
Android does not expose unrestricted autonomous control. Accessibility is powerful and user-controlled; FRIDAY only provides a bounded set of navigation and visible-UI actions. Wake phrase listening is foreground-service based, not a hardware DSP hotword engine, and Android/OEM policy may stop it.
