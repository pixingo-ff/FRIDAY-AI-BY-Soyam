# FRIDAY Desktop Companion

This is the PC-side companion for the video-inspired desktop dashboard. It runs on the same computer you want FRIDAY to interact with; a Replit cloud process cannot directly control your personal PC.

## Run

```bash
cd desktop-companion
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python companion.py
```

Open `http://127.0.0.1:8765`. Copy the one-time token printed in the terminal into the dashboard. Keep it private. The server binds to loopback by default, so it is not exposed to your LAN or public internet.

## Included actions

- Local desktop system information (read-only)
- Web search and BBC world/technology RSS headlines
- Open an HTTP/HTTPS URL in the desktop browser
- Open Maps and YouTube from dashboard shortcuts

There is deliberately no arbitrary shell execution, keystroke injection, file deletion, or unrestricted desktop control endpoint. Those features require a separate explicit permission and review design. This companion is separate from the Android APK; the Android app does not silently control a PC.
