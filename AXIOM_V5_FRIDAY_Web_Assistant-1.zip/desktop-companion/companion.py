"""Local-only FRIDAY desktop companion. No arbitrary shell/command endpoint."""
from __future__ import annotations
import os, platform, secrets, webbrowser
from urllib.parse import urlparse
from typing import Optional

import httpx
from bs4 import BeautifulSoup
from fastapi import FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, HttpUrl

TOKEN = os.getenv("FRIDAY_DESKTOP_TOKEN", "").strip() or secrets.token_urlsafe(24)
HOST = os.getenv("FRIDAY_DESKTOP_HOST", "127.0.0.1")
PORT = int(os.getenv("FRIDAY_DESKTOP_PORT", "8765"))
app = FastAPI(title="FRIDAY Desktop Companion", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=[f"http://127.0.0.1:{PORT}", f"http://localhost:{PORT}"], allow_methods=["GET", "POST"], allow_headers=["Authorization", "Content-Type"])

class OpenRequest(BaseModel):
    url: HttpUrl

class LaunchRequest(BaseModel):
    app: str


def authorize(value: Optional[str]):
    supplied = (value or "").removeprefix("Bearer ").strip()
    if not secrets.compare_digest(supplied, TOKEN):
        raise HTTPException(status_code=401, detail="Invalid desktop companion token")

@app.get("/", response_class=HTMLResponse)
def dashboard():
    return HTMLResponse(open(os.path.join(os.path.dirname(__file__), "dashboard.html"), encoding="utf-8").read())

@app.get("/api/health")
def health():
    return {"ok": True, "service": "FRIDAY Desktop Companion", "version": "1.0.0", "host": HOST, "port": PORT}

@app.get("/api/system-info")
def system_info(authorization: Optional[str] = Header(default=None)):
    authorize(authorization)
    return {"system": platform.system(), "release": platform.release(), "machine": platform.machine(), "python": platform.python_version(), "node": platform.node()}

@app.get("/api/search")
async def search(q: str = Query(min_length=2, max_length=180), authorization: Optional[str] = Header(default=None)):
    authorize(authorization)
    url = "https://html.duckduckgo.com/html/"
    async with httpx.AsyncClient(timeout=15, follow_redirects=True, headers={"User-Agent": "Mozilla/5.0 FRIDAY-Desktop/1.0"}) as client:
        response = await client.get(url, params={"q": q})
        response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    items = []
    for result in soup.select(".result")[:8]:
        link = result.select_one("a.result__a")
        snippet = result.select_one(".result__snippet")
        if link:
            items.append({"title": link.get_text(" ", strip=True), "url": link.get("href", ""), "snippet": snippet.get_text(" ", strip=True) if snippet else ""})
    return {"query": q, "results": items}

@app.get("/api/news")
async def news(authorization: Optional[str] = Header(default=None)):
    authorize(authorization)
    feeds = ["https://feeds.bbci.co.uk/news/world/rss.xml", "https://feeds.bbci.co.uk/news/technology/rss.xml"]
    output = []
    async with httpx.AsyncClient(timeout=12, follow_redirects=True, headers={"User-Agent": "FRIDAY-Desktop/1.0"}) as client:
        for feed in feeds:
            try:
                r = await client.get(feed); r.raise_for_status()
                soup = BeautifulSoup(r.text, "xml")
                for item in soup.find_all("item")[:6]:
                    output.append({"title": item.title.get_text(" ", strip=True) if item.title else "", "url": item.link.get_text(strip=True) if item.link else "", "published": item.pubDate.get_text(strip=True) if item.pubDate else ""})
            except Exception:
                continue
    return {"items": output[:12]}

@app.post("/api/open-url")
def open_url(body: OpenRequest, authorization: Optional[str] = Header(default=None)):
    authorize(authorization)
    parsed = urlparse(str(body.url))
    if parsed.scheme not in ("http", "https"):
        raise HTTPException(400, "Only http and https links are allowed")
    webbrowser.open(str(body.url), new=2)
    return {"ok": True, "opened": str(body.url)}

@app.post("/api/launch")
def launch(body: LaunchRequest, authorization: Optional[str] = Header(default=None)):
    authorize(authorization)
    # Deliberately limited to known application names; no shell commands are accepted.
    choices = {"browser": None}
    name = body.app.strip().lower()
    if name not in choices:
        raise HTTPException(400, "Supported desktop action: browser (use Open URL for websites)")
    webbrowser.open("https://www.google.com", new=2)
    return {"ok": True, "launched": "browser"}

if __name__ == "__main__":
    import uvicorn
    print("\nFRIDAY DESKTOP TOKEN (keep private):", TOKEN)
    print(f"Dashboard: http://{HOST}:{PORT}")
    uvicorn.run(app, host=HOST, port=PORT)
