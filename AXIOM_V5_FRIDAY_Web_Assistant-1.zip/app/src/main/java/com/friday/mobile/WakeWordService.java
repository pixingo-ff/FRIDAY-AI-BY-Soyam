package com.friday.mobile;

import android.app.*;
import android.content.*;
import android.os.*;
import android.speech.*;
import java.util.*;

/** User-started foreground microphone service. Uses the device speech recognition provider;
 * this is not a dedicated low-power DSP keyword engine and availability varies by device. */
public class WakeWordService extends Service {
  public static final String ACTION_START="com.friday.mobile.WAKE_START", ACTION_STOP="com.friday.mobile.WAKE_STOP";
  private static final String CHANNEL="friday_wake_channel";
  private SpeechRecognizer recognizer; private boolean running=false; private PowerManager.WakeLock cpuLock; private final Handler handler=new Handler(Looper.getMainLooper());
  @Override public void onCreate(){super.onCreate(); createChannel();}
  @Override public int onStartCommand(Intent intent,int flags,int startId){
    String action=intent==null?ACTION_START:intent.getAction();
    if(ACTION_STOP.equals(action)){stopSelf();return START_NOT_STICKY;}
    Notification n=new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("FRIDAY wake listening active").setContentText("Say ‘Hey Friday’ to activate the assistant").setOngoing(true).build();
    if(Build.VERSION.SDK_INT>=29) startForeground(42,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE); else startForeground(42,n);
    try { PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE); cpuLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"FRIDAY:WakeListening"); cpuLock.acquire(); } catch(Exception ignored) {}
    startRecognition(); return START_STICKY;
  }
  private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"FRIDAY wake word",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(c);}}
  private void startRecognition(){
    if(running)return; if(!SpeechRecognizer.isRecognitionAvailable(this)){stopSelf();return;} running=true;
    try{recognizer=Build.VERSION.SDK_INT>=31?SpeechRecognizer.createSpeechRecognizer(this):SpeechRecognizer.createSpeechRecognizer(this);
      recognizer.setRecognitionListener(new RecognitionListener(){
        public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){}
        public void onError(int e){restart();} public void onResults(Bundle b){check(b);restart();} public void onPartialResults(Bundle b){check(b);} public void onEvent(int e,Bundle b){}
      }); listen();
    }catch(Exception e){stopSelf();}
  }
  private void listen(){if(!running||recognizer==null)return;try{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault());i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);recognizer.startListening(i);}catch(Exception e){restart();}}
  private void check(Bundle b){if(b==null||!running)return;ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(a==null)return;for(String s:a){String t=s.toLowerCase(Locale.ROOT).replaceAll("[^a-z ]","").trim();if(t.contains("hey friday")||t.equals("friday")||t.startsWith("friday ")){running=false;try{recognizer.cancel();recognizer.destroy();}catch(Exception ignored){}recognizer=null;Intent launch=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("friday_wake_detected",true).putExtra("friday_wake_phrase",s);startActivity(launch);stopSelf();return;}}}
  private void restart(){if(!running)return;try{if(recognizer!=null){recognizer.cancel();recognizer.destroy();}}catch(Exception ignored){}recognizer=null;handler.postDelayed(()->{if(running){try{recognizer=SpeechRecognizer.createSpeechRecognizer(this);recognizer.setRecognitionListener(new RecognitionListener(){public void onReadyForSpeech(Bundle b){}public void onBeginningOfSpeech(){}public void onRmsChanged(float r){}public void onBufferReceived(byte[]b){}public void onEndOfSpeech(){}public void onError(int e){restart();}public void onResults(Bundle b){check(b);restart();}public void onPartialResults(Bundle b){check(b);}public void onEvent(int e,Bundle b){}});listen();}catch(Exception e){restart();}}},650);}
  @Override public void onDestroy(){running=false;handler.removeCallbacksAndMessages(null);if(recognizer!=null){try{recognizer.cancel();recognizer.destroy();}catch(Exception ignored){}}if(cpuLock!=null&&cpuLock.isHeld()){try{cpuLock.release();}catch(Exception ignored){}}stopForeground(true);super.onDestroy();}
  @Override public android.os.IBinder onBind(Intent i){return null;}
}
