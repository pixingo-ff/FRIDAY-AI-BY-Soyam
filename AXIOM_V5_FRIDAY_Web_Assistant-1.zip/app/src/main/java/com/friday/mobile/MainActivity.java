package com.friday.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.media.MediaPlayer;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private WebView web;
    private android.content.SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private TextToSpeech tts;
    private MediaPlayer fishPlayer;
    private String pendingListenCallback = "";
    private String pendingWakePhrase = null;
    private static final int SPEECH_REQUEST = 7104;
    private static final int AUDIO_PERMISSION_REQUEST = 7105;
    private static final String GEMINI_MODEL = "gemini-3.8-flash";
    private static final String GROQ_MODEL = "openai/gpt-oss-120b";
    private static final String FISH_REFERENCE_ID = "52f96bd908cd4509b3c98fd8cee40d6d";
    private static final String DEFAULT_FISH_SERVICE_MODEL = "s2.1-pro-free";
    private static final String KEYSTORE_ALIAS = "friday_api_keys_v1";
    private boolean wakeEnabled = false;
    private interface GeminiCallback { void onComplete(boolean success, String message); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(7, 12, 20));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(7, 12, 20));
        prefs = getSharedPreferences("friday_prefs", MODE_PRIVATE);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.getDefault());
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { js("window.fridaySpeechState && window.fridaySpeechState(true)"); }
                    @Override public void onDone(String utteranceId) { js("window.fridaySpeechState && window.fridaySpeechState(false)"); }
                    @Override public void onError(String utteranceId) { js("window.fridaySpeechState && window.fridaySpeechState(false)"); }
                });
                pushVoices();
            }
        });
        web = new WebView(this);
        web.setBackgroundColor(android.graphics.Color.rgb(7, 12, 20));
        WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(false); s.setAllowFileAccessFromFileURLs(false); s.setAllowUniversalAccessFromFileURLs(false); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (prefs.getBoolean("wake_enabled", false)) js("window.fridayWakeStatus && window.fridayWakeStatus(true,'Background wake service is enabled. A persistent Android notification appears while listening.')");
                if (pendingWakePhrase != null) { String phrase=pendingWakePhrase; pendingWakePhrase=null; js("window.fridayWakeDetected && window.fridayWakeDetected("+q(phrase)+")"); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("file:///android_asset/")) return false;
                if (url != null && (url.startsWith("https://") || url.startsWith("http://"))) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "No browser is available.", Toast.LENGTH_SHORT).show(); }
                    return true;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new FridayBridge(), "Friday");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        handleWakeIntent(getIntent());
    }

    private void js(String script) { runOnUiThread(() -> { if (web != null) web.evaluateJavascript(script, null); }); }
    private static String q(String s) { return JSONObject.quote(s == null ? "" : s); }

    private SecretKey getOrCreateEncryptionKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(KEYSTORE_ALIAS)) return (SecretKey) keyStore.getKey(KEYSTORE_ALIAS, null);
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEYSTORE_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    private String readSecret(String name) {
        String stored = prefs.getString(name, "");
        if (stored.isEmpty()) return "";
        if (!stored.startsWith("enc:v1:")) {
            // Migrate settings created by older builds from plain preferences to Keystore-backed encryption.
            if (writeSecret(name, stored)) return stored;
            prefs.edit().remove(name).apply();
            return "";
        }
        try {
            byte[] encrypted = Base64.decode(stored.substring("enc:v1:".length()), Base64.NO_WRAP);
            byte[] iv = Arrays.copyOfRange(encrypted, 0, 12);
            byte[] ciphertext = Arrays.copyOfRange(encrypted, 12, encrypted.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateEncryptionKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(ciphertext), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private boolean writeSecret(String name, String value) {
        if (value == null || value.trim().isEmpty()) {
            prefs.edit().remove(name).apply();
            return true;
        }
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateEncryptionKey());
            byte[] iv = cipher.getIV();
            byte[] ciphertext = cipher.doFinal(value.trim().getBytes(StandardCharsets.UTF_8));
            byte[] encrypted = new byte[iv.length + ciphertext.length];
            System.arraycopy(iv, 0, encrypted, 0, iv.length);
            System.arraycopy(ciphertext, 0, encrypted, iv.length, ciphertext.length);
            prefs.edit().putString(name, "enc:v1:" + Base64.encodeToString(encrypted, Base64.NO_WRAP)).apply();
            return true;
        } catch (Exception e) {
            runOnUiThread(() -> Toast.makeText(this, "Could not securely save this API key on this device.", Toast.LENGTH_LONG).show());
            return false;
        }
    }

    private class FridayBridge {
        @JavascriptInterface public String getApiKey() { return ""; }
        @JavascriptInterface public boolean hasApiKey() { return !readSecret("gemini_key").isEmpty(); }
        @JavascriptInterface public boolean hasAnyApiKey() { return !readSecret("gemini_key").isEmpty() || !readSecret("groq_key").isEmpty(); }
        @JavascriptInterface public String getPreferredProvider() { return prefs.getString("preferred_provider", "auto"); }
        @JavascriptInterface public void setPreferredProvider(String provider) {
            String safe = ("gemini".equals(provider) || "groq".equals(provider)) ? provider : "auto";
            prefs.edit().putString("preferred_provider", safe).apply();
        }
        @JavascriptInterface public String getGeminiModel() { return prefs.getString("gemini_model", GEMINI_MODEL); }
        @JavascriptInterface public String getGroqModel() { return prefs.getString("groq_model", GROQ_MODEL); }
        @JavascriptInterface public boolean setGeminiModel(String model) {
            if (model == null || !model.matches("gemini-[A-Za-z0-9._-]{2,80}")) return false;
            prefs.edit().putString("gemini_model", model.trim()).apply(); return true;
        }
        @JavascriptInterface public boolean setGroqModel(String model) {
            if (model == null || !model.matches("[A-Za-z0-9._/-]{3,100}")) return false;
            prefs.edit().putString("groq_model", model.trim()).apply(); return true;
        }
        @JavascriptInterface public void stopSpeaking() {
            runOnUiThread(() -> {
                if (tts != null) tts.stop();
                if (fishPlayer != null) { try { fishPlayer.pause(); fishPlayer.seekTo(0); } catch (Exception ignored) {} }
                js("window.fridaySpeechState && window.fridaySpeechState(false)");
            });
        }
        @JavascriptInterface public boolean saveApiKey(String key) { return key != null && !key.trim().isEmpty() && writeSecret("gemini_key", key); }
        @JavascriptInterface public void clearApiKey() { writeSecret("gemini_key", ""); }
        @JavascriptInterface public boolean hasGroqApiKey() { return !readSecret("groq_key").isEmpty(); }
        @JavascriptInterface public boolean saveGroqApiKey(String key) { return key != null && !key.trim().isEmpty() && writeSecret("groq_key", key); }
        @JavascriptInterface public void clearGroqApiKey() { writeSecret("groq_key", ""); }
        @JavascriptInterface public void testGroqConnection() {
            final String key = readSecret("groq_key");
            if (key.isEmpty()) { js("window.fridayGroqStatus && window.fridayGroqStatus(false,'Add a Groq API key first.')"); return; }
            js("window.fridayGroqStatus && window.fridayGroqStatus(null,'Testing Groq connection…')");
            requestGroq(key, "Reply with exactly: FRIDAY Groq connection confirmed.", (ok, message) ->
                js("window.fridayGroqStatus && window.fridayGroqStatus(" + ok + "," + q(ok ? "Connected · " + getGroqModel() : message) + ")"));
        }
        @JavascriptInterface public String getFishApiKey() { return ""; }
        @JavascriptInterface public String getFishModelId() { return prefs.getString("fish_audio_model", FISH_REFERENCE_ID); }
        @JavascriptInterface public String getFishServiceModel() { return prefs.getString("fish_service_model", DEFAULT_FISH_SERVICE_MODEL); }
        @JavascriptInterface public boolean hasFishApiKey() { return !readSecret("fish_audio_key").isEmpty(); }
        @JavascriptInterface public void saveFishSettings(String key, String modelId) {
            saveFishSettingsInternal(key, modelId, getFishServiceModel());
        }
        @JavascriptInterface public boolean saveFishSettingsWithModel(String key, String modelId, String serviceModel) {
            return saveFishSettingsInternal(key, modelId, serviceModel);
        }
        @JavascriptInterface public void clearFishApiKey() {
            writeSecret("fish_audio_key", "");
        }
        private boolean saveFishSettingsInternal(String key, String modelId, String serviceModel) {
            boolean saved = key == null || key.trim().isEmpty() || writeSecret("fish_audio_key", key);
            String safeModelId = modelId == null || modelId.trim().isEmpty() ? FISH_REFERENCE_ID : modelId.trim();
            String safeServiceModel = isSupportedFishModel(serviceModel) ? serviceModel : DEFAULT_FISH_SERVICE_MODEL;
            prefs.edit().putString("fish_audio_model", safeModelId)
                    .putString("fish_service_model", safeServiceModel).apply();
            return saved;
        }
        @JavascriptInterface public String getVoiceName() { return prefs.getString("voice_name", ""); }
        @JavascriptInterface public void setVoiceName(String name) {
            prefs.edit().putString("voice_name", name == null ? "" : name).apply();
            if (tts != null && tts.getVoices() != null) for (Voice v : tts.getVoices()) if (v.getName().equals(name)) { tts.setVoice(v); break; }
        }
        @JavascriptInterface public void speak(String text) {
            if (text == null || text.trim().isEmpty()) return;
            final String safeText = text.trim().length() > 2500 ? text.trim().substring(0, 2500) : text.trim();
            final String fishKey = readSecret("fish_audio_key");
            final String modelId = prefs.getString("fish_audio_model", FISH_REFERENCE_ID).trim();
            if (!fishKey.isEmpty() && !modelId.isEmpty()) {
                js("window.fridayFishStatus && window.fridayFishStatus('Generating Fish Audio speech…',true)");
                executor.execute(() -> speakWithFishAudio(safeText, fishKey, modelId));
            } else {
                speakWithAndroidTts(safeText);
            }
        }
        @JavascriptInterface public void listen(String callbackId) {
            runOnUiThread(() -> {
                pendingListenCallback = callbackId;
                if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    explainAndRequestAudioPermission(callbackId);
                } else beginListening();
            });
        }
        @JavascriptInterface public boolean isWakeEnabled() { return getSharedPreferences("friday_prefs", MODE_PRIVATE).getBoolean("wake_enabled", false); }
        @JavascriptInterface public void setWakeEnabled(boolean enabled) {
            runOnUiThread(() -> {
                if (!enabled) { stopService(new Intent(this, WakeWordService.class)); getSharedPreferences("friday_prefs", MODE_PRIVATE).edit().putBoolean("wake_enabled", false).apply(); js("window.fridayWakeStatus && window.fridayWakeStatus(false,'Background wake listening is off.')"); return; }
                if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) { pendingListenCallback = "wake"; explainAndRequestAudioPermission("wake"); return; }
                startWakeForegroundService();
            });
        }
        @JavascriptInterface public boolean isAccessibilityEnabled() { return FridayAccessibilityService.isEnabled(); }
        @JavascriptInterface public void openAccessibilitySettings() { runOnUiThread(() -> startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))); }
        @JavascriptInterface public boolean deviceAction(String action, String text) {
            if (action == null) return false;
            final String a=action.trim().toLowerCase(Locale.ROOT);
            if (!(a.equals("back")||a.equals("home")||a.equals("notifications")||a.equals("quick_settings")||a.equals("scroll_down")||a.equals("scroll_up")||a.equals("tap_text"))) return false;
            return FridayAccessibilityService.perform(a, text);
        }
        @JavascriptInterface public String getSystemSnapshot() {
            JSONObject info = new JSONObject();
            try {
                info.put("device", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL);
                info.put("android", "Android " + android.os.Build.VERSION.RELEASE + " · API " + android.os.Build.VERSION.SDK_INT);
                android.net.ConnectivityManager cm = (android.net.ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
                boolean online = false;
                if (cm != null && android.os.Build.VERSION.SDK_INT >= 23) {
                    android.net.Network network = cm.getActiveNetwork();
                    android.net.NetworkCapabilities caps = network == null ? null : cm.getNetworkCapabilities(network);
                    online = caps != null && caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
                }
                info.put("network", online ? "ONLINE" : "OFFLINE");
                info.put("battery", getBatteryInfo());
            } catch (Exception e) {
                try { info.put("error", "Device status unavailable"); } catch (Exception ignored) {}
            }
            return info.toString();
        }
        @JavascriptInterface public String getBatteryInfo() {
            android.content.IntentFilter f = new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED);
            android.content.Intent b = registerReceiver(null, f);
            if (b == null) return "Battery status unavailable.";
            int level = b.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
            int scale = b.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100);
            int pct = scale > 0 ? Math.round(level * 100f / scale) : level;
            int status = b.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1);
            return "Battery " + pct + "% · " + (status == android.os.BatteryManager.BATTERY_STATUS_CHARGING ? "charging" : status == android.os.BatteryManager.BATTERY_STATUS_FULL ? "full" : "not charging");
        }
        @JavascriptInterface public void ask(String prompt, String callbackId) {
            final String geminiKey = readSecret("gemini_key");
            final String groqKey = readSecret("groq_key");
            if (geminiKey.isEmpty() && groqKey.isEmpty()) { js("window.fridayReply(" + q(callbackId) + "," + q("Add a Gemini or Groq API key in Settings first, boss.") + ",false)"); return; }
            String preferred = prefs.getString("preferred_provider", "auto");
            boolean useGroqFirst = "groq".equals(preferred) || (geminiKey.isEmpty() && !groqKey.isEmpty());
            if ("gemini".equals(preferred) && geminiKey.isEmpty()) {
                js("window.fridayReply(" + q(callbackId) + "," + q("Gemini is selected, but no Gemini key is saved. Add one or select Auto/Groq in Settings.") + ",false)");
                return;
            }
            if (useGroqFirst) {
                if (groqKey.isEmpty()) { js("window.fridayReply(" + q(callbackId) + "," + q("Groq is selected, but no Groq key is saved.") + ",false)"); return; }
                requestGroq(groqKey, prompt, (ok, answer) -> {
                    if (!ok && "auto".equals(preferred) && !geminiKey.isEmpty()) requestGemini(geminiKey, prompt, (geminiOk, geminiAnswer) ->
                        js("window.fridayReply(" + q(callbackId) + "," + q(geminiOk ? "(Answered using Gemini fallback.)\\n\\n" + geminiAnswer : "Groq error: " + answer + "\\nGemini error: " + geminiAnswer) + "," + geminiOk + ")"));
                    else js("window.fridayReply(" + q(callbackId) + "," + q(answer) + "," + ok + ")");
                });
            } else {
                requestGemini(geminiKey, prompt, (success, message) -> {
                    if (success) js("window.fridayReply(" + q(callbackId) + "," + q(message) + ",true)");
                    else if ("auto".equals(preferred) && !groqKey.isEmpty()) requestGroq(groqKey, prompt, (groqOk, groqMessage) -> {
                        String prefix = groqOk ? "(Answered using Groq because Gemini was unavailable; live search grounding may not apply.)\\n\\n" : "Gemini error: " + message + "\\nGroq error: ";
                        js("window.fridayReply(" + q(callbackId) + "," + q(prefix + groqMessage) + "," + groqOk + ")");
                    });
                    else js("window.fridayReply(" + q(callbackId) + "," + q(message) + ",false)");
                });
            }
        }
        @JavascriptInterface public void testGeminiConnection() {
            final String key = readSecret("gemini_key");
            if (key.isEmpty()) {
                js("window.fridayGeminiStatus && window.fridayGeminiStatus(false,'Add a Gemini API key to test the connection.')");
                return;
            }
            js("window.fridayGeminiStatus && window.fridayGeminiStatus(null,'Testing Gemini connection…')");
            requestGemini(key, "Reply with exactly: FRIDAY connection confirmed.", (success, message) ->
                    js("window.fridayGeminiStatus && window.fridayGeminiStatus(" + success + "," +
                            q(success ? "Connected · " + getGeminiModel() : message) + ")"));
        }
        @JavascriptInterface public void searchWeb(String query) {
            String safe = query == null ? "" : query.trim();
            if (safe.isEmpty()) safe = "latest news";
            final String encoded = Uri.encode(safe);
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + encoded))); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "No browser is available.", Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public void searchMaps(String query) {
            String safe = query == null ? "" : query.trim();
            if (safe.isEmpty()) safe = "nearby places";
            final String encoded = Uri.encode(safe);
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + encoded))); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Maps is not available.", Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public void openAction(String action) {
            runOnUiThread(() -> {
                Intent i = null;
                switch (action == null ? "" : action) {
                    case "browser": i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")); break;
                    case "maps": i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com")); break;
                    case "search": i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=latest+news")); break;
                    case "settings": i = new Intent(android.provider.Settings.ACTION_SETTINGS); break;
                    case "wifi": i = new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS); break;
                    case "dialer": i = new Intent(Intent.ACTION_DIAL); break;
                    case "camera": i = new Intent("android.media.action.IMAGE_CAPTURE"); break;
                    case "clock": i = new Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS); break;
                    case "bluetooth": i = new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS); break;
                    case "location": i = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS); break;
                    case "volume": i = new Intent(android.provider.Settings.ACTION_SOUND_SETTINGS); break;
                    case "battery": js("window.fridayDeviceInfo(" + q(getBatteryInfo()) + ")"); return;
                }
                if (i != null) try { startActivity(i); } catch (Exception e) { Toast.makeText(MainActivity.this, "That action is not available on this phone", Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public String getVoices() {
            JSONArray arr = new JSONArray(); if (tts != null && tts.getVoices() != null) for (Voice v : tts.getVoices()) { if (v.getLocale() != null && v.getLocale().getLanguage().equals(Locale.getDefault().getLanguage())) { JSONObject o = new JSONObject(); try { o.put("name", v.getName()); o.put("label", v.getName() + (v.isNetworkConnectionRequired() ? " · online" : " · device")); arr.put(o); } catch (Exception ignored) {} } }
            return arr.toString();
        }
    }

    private boolean isSupportedFishModel(String model) {
        return "s1".equals(model) || "s2-pro".equals(model) || "s2.1-pro".equals(model) ||
                "s2.1-pro-free".equals(model) || "drama-3".equals(model);
    }

    private void requestGroq(String key, String prompt, GeminiCallback callback) {
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                String selectedModel = prefs.getString("groq_model", GROQ_MODEL);
                URL url = new URL("https://api.groq.com/openai/v1/chat/completions");
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(60000); conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                conn.setRequestProperty("Authorization", "Bearer " + key);
                JSONObject body = new JSONObject(); body.put("model", selectedModel); body.put("temperature", 0.6); body.put("max_completion_tokens", 1200); body.put("include_reasoning", false);
                JSONArray messages = new JSONArray();
                messages.put(new JSONObject().put("role", "system").put("content", "You are FRIDAY, an original warm, capable, female-presenting AI assistant for Soyam. Be concise, practical, calmly witty, and honest about limitations. You can open only the Android actions explicitly exposed by the app. You do not have live web search in this Groq request; say so when current facts need verification and suggest the in-app web search or maps shortcuts."));
                messages.put(new JSONObject().put("role", "user").put("content", prompt)); body.put("messages", messages);
                try (OutputStream out = conn.getOutputStream()) { out.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
                int code = conn.getResponseCode(); InputStream in = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
                StringBuilder raw = new StringBuilder(); if (in != null) try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) { String line; while ((line = reader.readLine()) != null) raw.append(line); }
                JSONObject response = raw.length() == 0 ? new JSONObject() : new JSONObject(raw.toString());
                if (code < 200 || code >= 300) { JSONObject err = response.optJSONObject("error"); String detail = err == null ? "" : err.optString("message", ""); if (detail.length() > 260) detail = detail.substring(0,260); callback.onComplete(false, "Groq returned HTTP " + code + (detail.isEmpty()?". Check API key and quota.":": " + detail)); return; }
                JSONArray choices = response.optJSONArray("choices"); JSONObject choice = choices == null || choices.length() == 0 ? null : choices.optJSONObject(0); JSONObject message = choice == null ? null : choice.optJSONObject("message"); String answer = message == null ? "" : message.optString("content", "").trim();
                callback.onComplete(!answer.isEmpty(), answer.isEmpty() ? "Groq connected but returned no readable answer." : answer);
            } catch (Exception e) { callback.onComplete(false, "Could not reach Groq. Check internet access and your API key." + (e.getMessage() == null ? "" : " (" + e.getMessage() + ")")); }
            finally { if (conn != null) conn.disconnect(); }
        });
    }

    private void requestGemini(String key, String prompt, GeminiCallback callback) {
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                String selectedModel = prefs.getString("gemini_model", GEMINI_MODEL);
                URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + selectedModel + ":generateContent");
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(60000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                conn.setRequestProperty("x-goog-api-key", key);

                JSONObject body = new JSONObject();
                JSONObject systemInstruction = new JSONObject();
                JSONArray systemParts = new JSONArray();
                systemParts.put(new JSONObject().put("text",
                        "You are FRIDAY, an original female-presenting AI companion for your user and owner Soyam. " +
                        "Treat Soyam as your boss and best friend: warm, loyal, steady, emotionally aware, encouraging, " +
                        "gently witty, and respectful without being blindly agreeable. Offer practical support in coding, " +
                        "study, planning, creativity, and difficult moments; do not claim to replace real human relationships " +
                        "or professional help. Your characterization is inspired by the broad fictional idea of a capable " +
                        "Stark-style assistant and themes across Marvel films and VisionQuest, but you are an original assistant, " +
                        "not the copyrighted movie character. Do not claim personal memories of watching films, invent exact " +
                        "movie scenes, or reproduce copyrighted dialogue. You may discuss public plot/lore at a high level if " +
                        "asked. Express emotion naturally without pretending to have human feelings. Be honest about capabilities. " +
                        "Only claim device control for actions explicitly exposed by this app. Use Google Search grounding for " +
                        "current facts and provide concise answers."));
                systemInstruction.put("parts", systemParts);
                body.put("systemInstruction", systemInstruction);
                JSONArray contents = new JSONArray();
                JSONObject content = new JSONObject();
                content.put("role", "user");
                content.put("parts", new JSONArray().put(new JSONObject().put("text", prompt)));
                contents.put(content);
                body.put("contents", contents);
                body.put("tools", new JSONArray().put(new JSONObject().put("google_search", new JSONObject())));
                JSONObject generation = new JSONObject();
                generation.put("maxOutputTokens", 1200);
                body.put("generationConfig", generation);

                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream out = conn.getOutputStream()) { out.write(bytes); }
                int code = conn.getResponseCode();
                InputStream input = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
                StringBuilder responseText = new StringBuilder();
                if (input != null) {
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) responseText.append(line);
                    }
                }
                JSONObject response = responseText.length() == 0 ? new JSONObject() : new JSONObject(responseText.toString());
                if (code < 200 || code >= 300) {
                    JSONObject error = response.optJSONObject("error");
                    String detail = error == null ? "" : error.optString("message", "");
                    if (detail.length() > 320) detail = detail.substring(0, 320);
                    callback.onComplete(false, "Gemini returned HTTP " + code +
                            (detail.isEmpty() ? ". Check the key, model access, and connection." : ": " + detail));
                    return;
                }

                JSONArray candidates = response.optJSONArray("candidates");
                if (candidates == null || candidates.length() == 0) {
                    JSONObject feedback = response.optJSONObject("promptFeedback");
                    String reason = feedback == null ? "" : feedback.optString("blockReason", "");
                    callback.onComplete(false, reason.isEmpty()
                            ? "Gemini connected, but returned no answer."
                            : "Gemini could not answer this prompt (" + reason + ").");
                    return;
                }
                JSONObject candidate = candidates.getJSONObject(0);
                JSONObject answerContent = candidate.optJSONObject("content");
                JSONArray parts = answerContent == null ? null : answerContent.optJSONArray("parts");
                StringBuilder answer = new StringBuilder();
                if (parts != null) {
                    for (int i = 0; i < parts.length(); i++) {
                        JSONObject part = parts.optJSONObject(i);
                        if (part != null && !part.optBoolean("thought", false)) {
                            String text = part.optString("text", "");
                            if (!text.isEmpty()) {
                                if (answer.length() > 0) answer.append('\n');
                                answer.append(text);
                            }
                        }
                    }
                }
                if (answer.length() == 0) answer.append("Gemini connected, but returned no readable answer.");

                JSONObject grounding = candidate.optJSONObject("groundingMetadata");
                JSONArray chunks = grounding == null ? null : grounding.optJSONArray("groundingChunks");
                Set<String> seenSources = new HashSet<>();
                ArrayList<String> sources = new ArrayList<>();
                if (chunks != null) {
                    for (int i = 0; i < chunks.length() && sources.size() < 4; i++) {
                        JSONObject chunk = chunks.optJSONObject(i);
                        JSONObject webSource = chunk == null ? null : chunk.optJSONObject("web");
                        if (webSource == null) continue;
                        String uri = webSource.optString("uri", "");
                        if (!uri.isEmpty() && seenSources.add(uri)) {
                            String title = webSource.optString("title", "");
                            sources.add((title.isEmpty() ? uri : title) + " — " + uri);
                        }
                    }
                }
                if (!sources.isEmpty()) {
                    answer.append("\n\nSources:\n");
                    for (String source : sources) answer.append("• ").append(source).append('\n');
                }
                callback.onComplete(true, answer.toString().trim());
            } catch (Exception e) {
                String detail = e.getMessage();
                callback.onComplete(false, "I couldn't reach Gemini. Check internet access and the API key." +
                        (detail == null || detail.isEmpty() ? "" : " (" + detail + ")"));
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    private void explainAndRequestAudioPermission(String callbackId) {
        new AlertDialog.Builder(this)
                .setTitle("Microphone access")
                .setMessage("FRIDAY uses the microphone for voice input when you ask, or for “Hey Friday” only after you enable it while the app is open.")
                .setNegativeButton("Not now", (dialog, which) -> {
                    if ("wake".equals(callbackId)) {
                        js("window.fridayWakeStatus && window.fridayWakeStatus(false,'Microphone access was not granted.')");
                    } else {
                        js("window.fridayListenResult(" + q(callbackId) + ",\"\")");
                    }
                })
                .setPositiveButton("Continue", (dialog, which) ->
                        requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION_REQUEST))
                .show();
    }

    private void speakWithAndroidTts(String text) {
        runOnUiThread(() -> {
            if (tts == null) return;
            try {
                String chosen = prefs.getString("voice_name", "");
                Set<Voice> voices = tts.getVoices();
                if (voices != null && !chosen.isEmpty()) for (Voice v : voices) if (v.getName().equals(chosen)) { tts.setVoice(v); break; }
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "friday_utterance");
            } catch (Exception ignored) { Toast.makeText(this, "Could not start speech playback.", Toast.LENGTH_SHORT).show(); }
        });
    }

    private void speakWithFishAudio(String text, String apiKey, String modelId) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL("https://api.fish.audio/v1/tts");
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(60000); conn.setDoOutput(true);
            conn.setRequestProperty("Authorization", "Bearer " + apiKey);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("model", prefs.getString("fish_service_model", DEFAULT_FISH_SERVICE_MODEL));
            JSONObject body = new JSONObject();
            body.put("text", text); body.put("reference_id", modelId); body.put("format", "mp3"); body.put("normalize", true);
            byte[] request = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = conn.getOutputStream()) { out.write(request); }
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) {
                String detail = "";
                InputStream err = conn.getErrorStream();
                if (err != null) try (BufferedReader br = new BufferedReader(new InputStreamReader(err, StandardCharsets.UTF_8))) { String line; while ((line = br.readLine()) != null) detail += line; }
                final String message = "Fish Audio returned HTTP " + code + (detail.isEmpty() ? "." : ". Check API key/model ID and Fish Audio access.");
                js("window.fridayFishStatus && window.fridayFishStatus(" + q(message) + ",false)");
                speakWithAndroidTts(text);
                return;
            }
            File audioFile = new File(getCacheDir(), "friday_voice.mp3");
            try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(audioFile)) {
                byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            }
            js("window.fridayFishStatus && window.fridayFishStatus('Fish Audio voice playing.',true)");
            runOnUiThread(() -> {
                try {
                    if (fishPlayer != null) { try { fishPlayer.stop(); } catch (Exception ignored) {} fishPlayer.release(); fishPlayer = null; }
                    fishPlayer = new MediaPlayer(); fishPlayer.setDataSource(audioFile.getAbsolutePath());
                    fishPlayer.setOnCompletionListener(mp -> { mp.release(); if (fishPlayer == mp) fishPlayer = null; js("window.fridaySpeechState && window.fridaySpeechState(false)"); });
                    fishPlayer.setOnErrorListener((mp, what, extra) -> { mp.release(); if (fishPlayer == mp) fishPlayer = null; js("window.fridaySpeechState && window.fridaySpeechState(false)"); speakWithAndroidTts(text); return true; });
                    fishPlayer.setOnPreparedListener(mp -> { js("window.fridaySpeechState && window.fridaySpeechState(true)"); mp.start(); }); fishPlayer.prepareAsync();
                } catch (Exception e) { speakWithAndroidTts(text); }
            });
        } catch (Exception e) {
            js("window.fridayFishStatus && window.fridayFishStatus('Fish Audio could not be reached. Using Android voice fallback.',false)");
            speakWithAndroidTts(text);
        } finally { if (conn != null) conn.disconnect(); }
    }

    private String getBatteryInfo() {
        android.content.Intent b = registerReceiver(null, new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED));
        if (b == null) return "Battery status unavailable.";
        int level = b.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1), scale = b.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100);
        int pct = scale > 0 ? Math.round(level * 100f / scale) : level;
        int status = b.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1);
        return "Battery " + pct + "% · " + (status == android.os.BatteryManager.BATTERY_STATUS_CHARGING ? "charging" : status == android.os.BatteryManager.BATTERY_STATUS_FULL ? "full" : "not charging");
    }
    private void pushVoices() { if (web != null) js("if(window.fridayVoicesUpdated)window.fridayVoicesUpdated();"); }

    private void startWakeForegroundService() {
        try {
            Intent i=new Intent(this,WakeWordService.class).setAction(WakeWordService.ACTION_START);
            if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            getSharedPreferences("friday_prefs",MODE_PRIVATE).edit().putBoolean("wake_enabled",true).apply();
            js("window.fridayWakeStatus && window.fridayWakeStatus(true,'Background wake service started. Say Hey Friday. Keep FRIDAY enabled in Android battery settings if your phone restricts background apps.')");
        } catch(Exception e) { js("window.fridayWakeStatus && window.fridayWakeStatus(false,'Android blocked background microphone startup. Open FRIDAY and enable it again.')"); }
    }
    private void handleWakeIntent(Intent intent) {
        if(intent!=null && intent.getBooleanExtra("friday_wake_detected",false)) {
            pendingWakePhrase=intent.getStringExtra("friday_wake_phrase");
            if(web!=null && web.getProgress()>=100 && pendingWakePhrase!=null) { String phrase=pendingWakePhrase; pendingWakePhrase=null; web.postDelayed(() -> js("window.fridayWakeDetected && window.fridayWakeDetected("+q(phrase)+")"),250); }
            intent.removeExtra("friday_wake_detected");
        }
    }
    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); handleWakeIntent(intent); }

    private void beginListening() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Friday");
        try { startActivityForResult(i, SPEECH_REQUEST); }
        catch (ActivityNotFoundException e) { js("window.fridayListenResult(" + q(pendingListenCallback) + ",\"\")"); Toast.makeText(MainActivity.this, "Speech recognition is not available on this device", Toast.LENGTH_LONG).show(); }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AUDIO_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) { if ("wake".equals(pendingListenCallback)) startWakeForegroundService(); else beginListening(); }
            else if ("wake".equals(pendingListenCallback)) {
                js("window.fridayWakeStatus && window.fridayWakeStatus(false,'Microphone permission is needed for wake listening.')");
                Toast.makeText(this, "Microphone permission is needed for wake listening", Toast.LENGTH_SHORT).show();
            } else { js("window.fridayListenResult(" + q(pendingListenCallback) + ",\"\")"); Toast.makeText(this, "Microphone permission is needed for voice input", Toast.LENGTH_SHORT).show(); }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST) {
            String text = "";
            if (resultCode == RESULT_OK && data != null) { ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS); if (results != null && !results.isEmpty()) text = results.get(0); }
            js("window.fridayListenResult(" + q(pendingListenCallback) + "," + q(text) + ")");
        }
    }
    @Override public void onBackPressed() { if (web != null) web.evaluateJavascript("window.fridayBack ? window.fridayBack() : false", null); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } if (fishPlayer != null) { try { fishPlayer.stop(); } catch (Exception ignored) {} fishPlayer.release(); fishPlayer = null; } executor.shutdownNow(); super.onDestroy(); }
}
