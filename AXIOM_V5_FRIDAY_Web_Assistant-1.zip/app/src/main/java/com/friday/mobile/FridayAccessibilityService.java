package com.friday.mobile;

import android.accessibilityservice.*;
import android.view.accessibility.*;
import android.content.*;
import android.os.*;
import java.util.*;

/** Optional user-enabled accessibility bridge. Only exposes navigation and visible UI actions. */
public class FridayAccessibilityService extends AccessibilityService {
  private static FridayAccessibilityService instance;
  public void onServiceConnected(){instance=this;}
  public void onAccessibilityEvent(AccessibilityEvent e){}
  public void onInterrupt(){}
  public void onDestroy(){if(instance==this)instance=null;super.onDestroy();}
  public static boolean isEnabled(){return instance!=null;}
  public static boolean perform(String action,String text){FridayAccessibilityService s=instance;if(s==null)return false;return s.runAction(action,text==null?"":text);}
  private boolean runAction(String action,String text){
    if("back".equals(action))return performGlobalAction(GLOBAL_ACTION_BACK);
    if("home".equals(action))return performGlobalAction(GLOBAL_ACTION_HOME);
    if("notifications".equals(action))return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
    if("quick_settings".equals(action))return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
    if("scroll_down".equals(action)||"scroll_up".equals(action)){AccessibilityNodeInfo root=getRootInActiveWindow();return scroll(root,"scroll_down".equals(action)?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);}
    if("tap_text".equals(action)&&!text.trim().isEmpty()){AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return false;List<AccessibilityNodeInfo> nodes=root.findAccessibilityNodeInfosByText(text);for(AccessibilityNodeInfo n:nodes){if(n.isClickable()&&n.isEnabled())return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);AccessibilityNodeInfo p=n.getParent();while(p!=null){if(p.isClickable()&&p.isEnabled())return p.performAction(AccessibilityNodeInfo.ACTION_CLICK);p=p.getParent();}}}
    return false;
  }
  private boolean scroll(AccessibilityNodeInfo n,int action){if(n==null)return false;if(n.isScrollable()&&n.performAction(action))return true;for(int i=0;i<n.getChildCount();i++)if(scroll(n.getChild(i),action))return true;return false;}
}
