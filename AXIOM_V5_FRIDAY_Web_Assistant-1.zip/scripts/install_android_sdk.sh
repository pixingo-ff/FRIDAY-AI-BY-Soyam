#!/usr/bin/env bash
set -euo pipefail
SDK_ROOT="${ANDROID_HOME:-$HOME/android-sdk}"
TOOLS_VERSION_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$SDK_ROOT/cmdline-tools"
if [[ ! -x "$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" ]]; then
  echo "Downloading Android command-line tools..."
  curl -fL --retry 3 "$TOOLS_VERSION_URL" -o "$TMP/tools.zip"
  unzip -q "$TMP/tools.zip" -d "$TMP/unpack"
  rm -rf "$SDK_ROOT/cmdline-tools/latest"
  mv "$TMP/unpack/cmdline-tools" "$SDK_ROOT/cmdline-tools/latest"
fi
export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"
yes | sdkmanager --licenses >/dev/null 2>&1 || true
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"
echo "Android SDK installed at $ANDROID_HOME"
echo "Run: ANDROID_HOME=$ANDROID_HOME ANDROID_SDK_ROOT=$ANDROID_HOME bash scripts/build_replit.sh"
