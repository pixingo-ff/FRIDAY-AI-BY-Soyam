#!/usr/bin/env bash
set -euo pipefail

# Replit Android build helper. Requires an Android SDK installed in the workspace.
export JAVA_HOME="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(command -v java)")")")}" 
export PATH="$JAVA_HOME/bin:$PATH"

if [[ -z "${ANDROID_HOME:-}" ]]; then
  for candidate in "$HOME/Android/Sdk" "$HOME/android-sdk" "/opt/android-sdk" "/usr/lib/android-sdk"; do
    if [[ -d "$candidate" ]]; then export ANDROID_HOME="$candidate"; break; fi
  done
fi
if [[ -z "${ANDROID_HOME:-}" || ! -d "$ANDROID_HOME" ]]; then
  echo "ERROR: Android SDK not found. Install Android command-line tools in Replit, set ANDROID_HOME, then run this script again."
  echo "Required packages: platform-tools, platforms;android-35, build-tools;35.0.0."
  exit 2
fi
export ANDROID_SDK_ROOT="$ANDROID_HOME"
SDKMANAGER="$(find "$ANDROID_HOME" -type f -name sdkmanager 2>/dev/null | head -n 1 || true)"
if [[ -n "$SDKMANAGER" ]]; then
  yes | "$SDKMANAGER" --licenses >/dev/null 2>&1 || true
  "$SDKMANAGER" "platform-tools" "platforms;android-35" "build-tools;35.0.0"
fi

if [[ ! -d "$ANDROID_HOME/platforms/android-35" ]]; then
  echo "ERROR: Missing $ANDROID_HOME/platforms/android-35. Install Android SDK Platform 35 using sdkmanager."
  exit 3
fi

./gradlew --no-daemon --stacktrace assembleDebug
APK="app/build/outputs/apk/debug/app-debug.apk"
if [[ -f "$APK" ]]; then
  echo "\nSUCCESS: Debug APK created at $APK"
else
  echo "Build finished but APK was not found at $APK"
  exit 4
fi
