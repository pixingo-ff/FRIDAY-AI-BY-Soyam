# FRIDAY AI — Android Mobile Command Centre

This is an Android phone application based on the supplied `AXIOM_V5_FRIDAY_Web_Assistant-1.zip` project. It is not a desktop application or a website-only replacement. The UI is a mobile-first WebView packaged inside a native Java Android Activity.

## Current Android features

- Original FRIDAY logo and orange reactor artwork retained from the supplied project.
- Portrait command-centre dashboard with animated idle/listening/thinking/speaking/error states.
- Chat console, local conversation archive, personal memory notes and owner profile.
- Gemini 3.8 Flash with Google Search grounding and editable model ID.
- Groq GPT-OSS 120B provider with editable model ID.
- Provider routing: Auto (Gemini first, Groq fallback), Gemini-only, or Groq-only; editable model IDs in Settings.
- API connection tests, editable model IDs and key removal controls.
- API keys encrypted using Android Keystore AES-GCM and stored in private app preferences.
- Android SpeechRecognizer input and installed Android TextToSpeech voices.
- Optional Fish Audio cloud speech generation with Android TTS fallback.
- Stop-speech control to interrupt TTS or Fish Audio playback.
- Foreground-only “Hey Friday” phrase listener while the app is open.
- Live device panel: manufacturer/model, Android version, network connectivity and battery state.
- Android intents for browser, Google Maps, Android Settings, Wi-Fi, dialer, camera, alarms, Bluetooth, location and sound settings.
- Text commands such as `search web for ...` and `navigate to ...` open real Google Search/Maps results.
- Retained original Python backend source under `original-friday-backend/` for separate future development; it is not required to run the Android app.

## Video reference analysis

The supplied 196.8-second reference video was inspected at regular intervals across its duration. It presents a desktop-and-phone assistant concept with a cinematic glowing core, voice-driven interaction, command panels, web/news/map-style information and phone companion screens. This project adapts the visual direction and supported phone actions to Android. It does not reproduce the video's proprietary desktop automation, hand tracking, unrestricted computer control or every spoken workflow.

## Provider setup

1. Create a Gemini API key in [Google AI Studio](https://aistudio.google.com/apikey) and/or a Groq key in [Groq Console](https://console.groq.com/keys).
2. Install FRIDAY and open **Settings**.
3. Paste a key into its field and save it. The key is encrypted on the device; the app never reads the saved secret back into the page.
4. Use the provider's **Test connection** button.
5. Select **Auto**, **Gemini only** or **Groq only**.
6. Optional: add a Fish Audio key and a valid voice reference ID to enable Fish Audio speech. Otherwise Android TTS is used.

Model IDs in this source:
- Gemini: `gemini-3.8-flash` (Google Search grounding enabled).
- Groq: `openai/gpt-oss-120b` (text chat; this app does not currently invoke Groq's browser-search or function-calling tools).
- Fish Audio synthesis model and reference ID are configurable in app Settings.

Provider model availability, account entitlements, quotas and pricing can change. Confirm the current model list and terms with the provider before deployment.

## Build a Debug APK

Requirements:
- JDK 17 or newer.
- Android SDK Platform 35.
- Android Build Tools 35.0.0.
- Internet access to download Gradle 8.9 and Android SDK packages.

The included `gradlew` is a lightweight pinned Gradle bootstrap script: it downloads Gradle 8.9 on first run. It is not the standard binary Gradle Wrapper JAR distribution.

### Replit / Linux

From the project root:

```bash
bash scripts/install_android_sdk.sh
ANDROID_HOME="$HOME/android-sdk" ANDROID_SDK_ROOT="$HOME/android-sdk" bash scripts/build_replit.sh
```

The APK output is:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Replit is the build environment; the resulting APK runs on Android phones. A Replit web preview is not an Android emulator.

### Android Studio

Open this folder as an existing Gradle project, ensure JDK 17+ and Android SDK Platform 35 are installed, then run:

```bash
./gradlew assembleDebug
```

## Permissions and Android boundaries

- `INTERNET`: provider requests, Fish Audio speech and browser/map URLs.
- `ACCESS_NETWORK_STATE`: network status display.
- `RECORD_AUDIO`: requested when the user starts voice input or enables the foreground wake listener.
- Camera is opened through an Android intent; the app does not directly capture images.
- System-setting shortcuts open Android settings screens. They do not silently change protected settings.
- Background wake phrase listening is provided by a user-started microphone foreground service with a persistent notification; it depends on the phone's SpeechRecognizer provider and is not a dedicated low-power DSP hotword engine.
- Optional Accessibility automation supports a bounded set of explicit navigation actions (Back, Home, notifications, quick settings, scrolling and confirmed taps on visible text). It is not unrestricted device control. Notification contents are not read.
- No assistant feature can bypass Android permission prompts or app sandbox restrictions.

## Privacy and storage

- API keys are encrypted with Android Keystore AES-GCM and kept in private app preferences.
- Chat history, response-style preference, owner profile and memory notes are stored locally in WebView local storage.
- Clearing chat removes the local conversation archive. Memory notes are separate and can be edited in Settings.
- API requests send the current prompt/context to the selected provider. Avoid storing passwords or sensitive secrets in personal notes.

## Verification status for this delivery

- JavaScript syntax checks: passed.
- Android manifest and resource XML parsing: passed.
- Shell syntax checks for build/install scripts: passed.
- ZIP integrity: checked after packaging.
- Android APK build: **not completed in this environment**. The workspace has JDK 21 but no Android SDK, and Android SDK download failed because `dl.google.com` could not be resolved. No APK is included or claimed as built.
- Provider live API tests: not run because no user API keys were supplied.
- Device launch, runtime permissions, voice playback and real phone intents: require an Android device/emulator and remain unverified here.

See `BUILD_REPORT.md` and `FRIDAY_FEATURES.md` for the exact implementation/test boundaries.

## Background wake phrase and Android automation (permissioned)

### Background “Hey Friday”
- Open FRIDAY and tap **Enable “Hey Friday”** while the app is visible.
- Grant microphone permission. Android shows a persistent foreground-service notification while listening.
- Say “Hey Friday” to bring FRIDAY to the foreground. The app then starts a normal interactive voice turn.
- Disable wake listening with the same button or from Android's foreground-service controls.
- This implementation uses Android's installed `SpeechRecognizer` provider in a microphone foreground service. It is not a dedicated always-on DSP/low-power keyword detector; recognition, offline availability, battery use, and background survival vary by phone and vendor. Android can stop the service, and the user must start it again. No boot auto-start is attempted.
- Android 14+ requires microphone foreground-service permissions and an eligible user-visible start. The app deliberately starts it only from the in-app user action.

### Accessibility automation
- Open Settings → Android automation bridge → **Open Accessibility settings**.
- Select **FRIDAY AI** and enable the service only if you want device navigation automation.
- Supported explicit commands include: `go back`, `go home`, `show notifications`, `open quick settings`, `scroll down`, `scroll up`, and `tap <visible text>`.
- `tap <visible text>` asks for confirmation first. Actions operate on visible accessibility nodes and may not work in protected, secure, custom-rendered, or unsupported apps.
- Accessibility is a sensitive Android permission. FRIDAY does not silently grant it, bypass lock screens, read passwords, approve system dialogs, send messages, make purchases, or claim unrestricted device control. Android permissions and each target app's restrictions remain authoritative.
