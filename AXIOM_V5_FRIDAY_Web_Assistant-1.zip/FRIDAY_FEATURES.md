# FRIDAY AI — Android Feature Inventory

## Implemented in source
- Android Java Activity + local WebView UI, portrait-first.
- Original FRIDAY artwork and animated reactor states.
- Home command dashboard, chat, settings and conversation archive screens.
- Local chat history and editable personal memory notes.
- Gemini 3.8 Flash REST integration with Google Search grounding.
- Groq GPT-OSS 120B REST integration.
- Auto/Gemini/Groq provider routing and configured fallback.
- API key encryption with Android Keystore AES-GCM.
- Gemini and Groq connection-test controls.
- Android speech-to-text, Android TTS voice selection, Fish Audio TTS option.
- Stop-speaking bridge for TTS/Fish Audio playback.
- Background wake phrase foreground service (SpeechRecognizer-based; device/provider dependent).
- Battery, device, Android version and connectivity status panel.
- Browser and Maps searches through Android intents.
- Settings shortcuts for Wi-Fi, Bluetooth, Location, Sound, Android Settings, Dialer, Camera and Alarms.
- Replit/Linux SDK installer and Debug APK build script.

## Not implemented / not verified
- No dedicated low-power DSP wake-word engine; background recognition depends on Android SpeechRecognizer and may be restricted by device power management.
- No streaming, full-duplex real-time speech conversation; voice input and TTS are separate steps.
- No automatic speech playback for every AI response; each assistant message has a Speak action.
- No live weather/news API client or native in-app search results panel. Gemini Search grounding can retrieve current information; the web-search command opens Google Search in the browser.
- Groq calls do not currently invoke its browser-search or function-calling tools.
- No notification-content reading, arbitrary installed-app discovery/launch, direct flashlight/volume mutation, screen OCR, hand tracking, or unrestricted device automation. Accessibility automation is limited to the documented user-requested navigation actions.
- No remote PC control. The Android app does not depend on a separate desktop program.
- No runtime test against provider APIs because no API keys were provided.
- No APK build completed in this workspace due to unavailable Android SDK download.

## Android background wake + automation update (v1.2.0)
- **Foreground wake phrase service:** user-started microphone foreground service, persistent notification, background listening attempt, wake phrase detection and foreground app handoff.
- **Android accessibility bridge:** optional user-enabled AccessibilityService for Back, Home, notifications, quick settings, scrolling, and confirmed tap-by-visible-text commands.
- **Security model:** explicit Android permissions; no silent accessibility enablement, lock-screen bypass, secret dialog approvals, or unrestricted system control.
- **Important:** wake detection uses Android's SpeechRecognizer service, not a dedicated always-on DSP keyword engine. It may use network recognition, consume significant battery, or be stopped by device power management. Wake reliability must be validated on each target phone.
